/**
 * Author: Nicolae Malai
 * Email: a23495@alunos.ipca.pt
 * Github: niiK0
 * Date: 27/03/2022
 * Descrição: Main.c , Trabalho Pratico - EDA
 */

#include <stdio.h>
#include <stdlib.h>
#include "headers/structs.h"
#include "headers/menus.h"

void main(){
    MainMenu();
}